import React, { useState, useEffect, useCallback } from 'react';
import { RefreshCw, Download, CheckCircle, AlertCircle, Cloud, CloudOff, Package, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';
import { isUpdateAvailable, downloadUpdate, applyUpdate, getCurrentVersion, getInitialStatus, UpdateStatus } from '../utils/updateService';

interface UpdateServiceScreenProps {
  onClose?: () => void;
  onUpdateApplied?: () => void;
}

const UpdateServiceScreen: React.FC<UpdateServiceScreenProps> = ({ onClose, onUpdateApplied }) => {
  const [status, setStatus] = useState<UpdateStatus>(getInitialStatus);
  const [expanded, setExpanded] = useState(false);

  const checkForUpdates = useCallback(async () => {
    setStatus(prev => ({ ...prev, checking: true, error: null }));
    const result = await isUpdateAvailable();
    setStatus(prev => ({
      ...prev,
      checking: false,
      available: result.available,
      latestVersion: result.latestVersion?.version || null,
      releaseNotes: result.latestVersion?.releaseNotes || null,
      error: result.error
    }));
  }, []);

  const handleDownload = useCallback(async () => {
    if (!status.latestVersion) return;
    setStatus(prev => ({ ...prev, downloading: true, progress: 0, error: null }));
    const success = await downloadUpdate(
      { version: status.latestVersion, buildNumber: 0, releaseNotes: status.releaseNotes || '', updateUrl: '', minAppVersion: '' },
      (progress) => setStatus(prev => ({ ...prev, progress }))
    );
    if (success) {
      setStatus(prev => ({ ...prev, downloading: false, ready: true, progress: 100 }));
    } else {
      setStatus(prev => ({ ...prev, downloading: false, error: 'فشل تحميل التحديث' }));
    }
  }, [status.latestVersion, status.releaseNotes]);

  const handleApply = useCallback(() => {
    applyUpdate();
    onUpdateApplied?.();
  }, [onUpdateApplied]);

  useEffect(() => {
    checkForUpdates();
  }, [checkForUpdates]);

  return (
    <div className="bg-slate-800 rounded-3xl border border-slate-700 shadow-2xl overflow-hidden">
      <div className="bg-gradient-to-l from-blue-600 to-blue-700 p-6 text-white">
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-3 rounded-2xl">
            <Package size={28} />
          </div>
          <div>
            <h2 className="text-xl font-black">خدمة التحديثات</h2>
            <p className="text-blue-200 text-[10px] font-bold uppercase tracking-widest">Update Service</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Current Version */}
        <div className="bg-slate-900/50 rounded-2xl p-4 border border-slate-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center">
                <Package size={20} className="text-blue-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">الإصدار الحالي</p>
                <p className="text-white font-black text-lg">{status.currentVersion}</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {navigator.onLine ? (
                <Cloud size={14} className="text-green-400" />
              ) : (
                <CloudOff size={14} className="text-red-400" />
              )}
              <span className={`text-[10px] font-black ${navigator.onLine ? 'text-green-400' : 'text-red-400'}`}>
                {navigator.onLine ? 'متصل' : 'غير متصل'}
              </span>
            </div>
          </div>
        </div>

        {/* Check for Updates Button */}
        <button
          onClick={checkForUpdates}
          disabled={status.checking || !navigator.onLine}
          className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black py-4 rounded-2xl transition-all shadow-lg active:scale-95"
        >
          <RefreshCw size={20} className={status.checking ? 'animate-spin' : ''} />
          {status.checking ? 'جاري الفحص...' : 'التحقق من وجود تحديثات'}
        </button>

        {/* Status Display */}
        {status.error === 'OFFLINE' && (
          <div className="p-4 bg-red-900/20 border border-red-800/50 rounded-2xl flex items-center gap-3">
            <AlertCircle size={20} className="text-red-400 shrink-0" />
            <div>
              <p className="text-red-400 text-xs font-bold">لا يوجد اتصال بالإنترنت</p>
              <p className="text-red-500/70 text-[10px] font-bold">تحقق من الاتصال وحاول مرة أخرى</p>
            </div>
          </div>
        )}

        {status.error && status.error !== 'OFFLINE' && (
          <div className="p-4 bg-red-900/20 border border-red-800/50 rounded-2xl flex items-center gap-3">
            <AlertCircle size={20} className="text-red-400 shrink-0" />
            <div>
              <p className="text-red-400 text-xs font-bold">فشل التحقق من التحديثات</p>
              <p className="text-red-500/70 text-[10px] font-bold">{status.error}</p>
            </div>
          </div>
        )}

        {/* Update Available */}
        {status.available && !status.downloading && !status.ready && (
          <div className="space-y-4">
            <div className="p-4 bg-emerald-900/20 border border-emerald-800/50 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                <CheckCircle size={20} className="text-emerald-400 shrink-0" />
                <div>
                  <p className="text-emerald-400 text-sm font-black">تحديث متاح!</p>
                  <p className="text-emerald-500/70 text-[10px] font-bold">الإصدار {status.latestVersion} متاح للتحميل</p>
                </div>
              </div>
              {status.releaseNotes && (
                <button
                  onClick={() => setExpanded(!expanded)}
                  className="flex items-center gap-1 text-[10px] text-emerald-400/70 font-bold"
                >
                  {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                  ملاحظات الإصدار
                </button>
              )}
              {expanded && status.releaseNotes && (
                <p className="mt-2 text-xs text-emerald-300/60 font-bold bg-emerald-950/30 p-3 rounded-xl">
                  {status.releaseNotes}
                </p>
              )}
            </div>
            <button
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black py-4 rounded-2xl transition-all shadow-lg active:scale-95"
            >
              <Download size={20} />
              تحميل وتثبيت التحديث
            </button>
          </div>
        )}

        {/* Downloading Progress */}
        {status.downloading && (
          <div className="space-y-4">
            <div className="p-4 bg-blue-900/20 border border-blue-800/50 rounded-2xl">
              <div className="flex items-center gap-3 mb-4">
                <RotateCcw size={20} className="text-blue-400 animate-spin shrink-0" />
                <div>
                  <p className="text-blue-400 text-sm font-black">جاري تحميل التحديث...</p>
                  <p className="text-blue-500/70 text-[10px] font-bold">{Math.round(status.progress)}%</p>
                </div>
              </div>
              <div className="w-full h-3 bg-slate-700 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-l from-blue-500 to-emerald-500 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${status.progress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Ready to Apply */}
        {status.ready && (
          <div className="space-y-4">
            <div className="p-4 bg-emerald-900/20 border border-emerald-800/50 rounded-2xl">
              <div className="flex items-center gap-3">
                <CheckCircle size={24} className="text-emerald-400 shrink-0" />
                <div>
                  <p className="text-emerald-400 text-sm font-black">التحديث جاهز للتطبيق!</p>
                  <p className="text-emerald-500/70 text-[10px] font-bold">سيتم إعادة تشغيل التطبيق لتطبيق التحديث</p>
                </div>
              </div>
            </div>
            <button
              onClick={handleApply}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black py-4 rounded-2xl transition-all shadow-lg active:scale-95 animate-pulse"
            >
              <RotateCcw size={20} />
              إعادة التشغيل لتطبيق التحديث
            </button>
          </div>
        )}

        {/* Up to Date */}
        {!status.checking && !status.available && !status.downloading && !status.ready && !status.error && (
          <div className="p-4 bg-slate-900/50 border border-slate-700 rounded-2xl flex items-center gap-3">
            <CheckCircle size={20} className="text-blue-400 shrink-0" />
            <div>
              <p className="text-blue-400 text-xs font-black">التطبيق محدث!</p>
              <p className="text-slate-500 text-[10px] font-bold">أنت تستخدم أحدث إصدار ({status.currentVersion})</p>
            </div>
          </div>
        )}

        {/* Close Button */}
        {onClose && (
          <button
            onClick={onClose}
            className="w-full text-slate-500 hover:text-white font-black py-3 rounded-xl transition-all text-xs border border-slate-700 hover:border-slate-600"
          >
            إغلاق
          </button>
        )}
      </div>
    </div>
  );
};

export default UpdateServiceScreen;
