import React from 'react';
import { WifiOff, RefreshCw, Wifi } from 'lucide-react';

interface NoInternetScreenProps {
  onRetry?: () => void;
  message?: string;
}

const NoInternetScreen: React.FC<NoInternetScreenProps> = ({
  onRetry,
  message = 'لا يوجد اتصال بالإنترنت'
}) => {
  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col items-center justify-center p-6">
      <div className="relative mb-8">
        <div className="w-28 h-28 bg-slate-800 rounded-full flex items-center justify-center border-4 border-slate-700">
          <WifiOff size={56} className="text-red-400" />
        </div>
        <div className="absolute -top-2 -right-2 w-10 h-10 bg-red-500/20 rounded-full flex items-center justify-center animate-ping">
          <div className="w-3 h-3 bg-red-500 rounded-full" />
        </div>
      </div>

      <h2 className="text-2xl font-black text-white mb-3 text-center">لا يوجد اتصال</h2>
      <p className="text-slate-400 text-sm font-bold text-center max-w-xs leading-relaxed mb-8">
        {message}
      </p>

      <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 max-w-sm w-full mb-8">
        <div className="space-y-4">
          <div className="flex items-center gap-3 text-slate-300">
            <div className="w-8 h-8 bg-slate-700 rounded-xl flex items-center justify-center shrink-0">
              <Wifi size={16} className="text-slate-400" />
            </div>
            <div>
              <p className="text-xs font-bold">تأكد من اتصال Wi-Fi أو بيانات الهاتف</p>
              <p className="text-[10px] text-slate-500">قد تحتاج للاقتراب من مصدر الإشارة</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-slate-300">
            <div className="w-8 h-8 bg-slate-700 rounded-xl flex items-center justify-center shrink-0">
              <RefreshCw size={16} className="text-slate-400" />
            </div>
            <div>
              <p className="text-xs font-bold">أعد المحاولة بعد التأكد من الاتصال</p>
              <p className="text-[10px] text-slate-500">التطبيق سيحاول الاتصال تلقائياً</p>
            </div>
          </div>
        </div>
      </div>

      {onRetry && (
        <button
          onClick={onRetry}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-black px-8 py-4 rounded-2xl shadow-lg shadow-blue-600/20 transition-all active:scale-95"
        >
          <RefreshCw size={20} />
          إعادة المحاولة
        </button>
      )}

      <p className="mt-8 text-[10px] text-slate-600 font-bold text-center">
        سيتم تشغيل التطبيق تلقائياً عند توفر الاتصال
      </p>
    </div>
  );
};

export default NoInternetScreen;
