import React from 'react';
import { Loader2, RefreshCw } from 'lucide-react';

interface LoadingScreenProps {
  message?: string;
  subMessage?: string;
  showProgress?: boolean;
  progress?: number;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({
  message = 'جاري تحميل التطبيق...',
  subMessage,
  showProgress = false,
  progress = 0
}) => {
  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900 flex flex-col items-center justify-center">
      <div className="relative">
        <div className="w-24 h-24 bg-blue-600 rounded-3xl flex items-center justify-center shadow-2xl shadow-blue-600/30 animate-pulse">
          <RefreshCw size={48} className="text-white animate-spin" />
        </div>
        <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-500/30">
          <Loader2 size={18} className="text-white animate-spin" />
        </div>
      </div>

      <h1 className="mt-8 text-3xl font-black text-white tracking-tighter uppercase">Uniteam</h1>
      <p className="mt-2 text-blue-300 text-sm font-bold">{message}</p>

      {subMessage && (
        <p className="mt-1 text-slate-500 text-[10px] font-black uppercase tracking-widest">{subMessage}</p>
      )}

      {showProgress && (
        <div className="mt-8 w-64">
          <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full transition-all duration-500 ease-out"
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
            />
          </div>
          <p className="mt-2 text-center text-slate-400 text-[10px] font-bold">{Math.round(progress)}%</p>
        </div>
      )}

      <div className="absolute bottom-8 flex gap-2">
        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
    </div>
  );
};

export default LoadingScreen;
