import { Capacitor } from '@capacitor/core';

const VERSION_CACHE_KEY = 'uniteam_app_version';
export const UPDATE_BASE_URL = 'https://rtmteam.github.io/Uniteam-v5';

export interface AppVersion {
  version: string;
  buildNumber: number;
  releaseNotes: string;
  updateUrl: string;
  minAppVersion: string;
}

export interface UpdateStatus {
  checking: boolean;
  available: boolean;
  downloading: boolean;
  progress: number;
  ready: boolean;
  error: string | null;
  currentVersion: string;
  latestVersion: string | null;
  releaseNotes: string | null;
}

export const getCurrentVersion = (): string => {
  const cached = localStorage.getItem(VERSION_CACHE_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      return parsed.version || '1.0.0';
    } catch (e) {
      return '1.0.0';
    }
  }
  return '1.0.0';
};

export const getCachedVersionInfo = (): AppVersion | null => {
  const cached = localStorage.getItem(VERSION_CACHE_KEY);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch (e) {
      return null;
    }
  }
  return null;
};

export const cacheCurrentVersion = (version: AppVersion): void => {
  localStorage.setItem(VERSION_CACHE_KEY, JSON.stringify(version));
};

export const fetchLatestVersion = async (): Promise<AppVersion | null> => {
  try {
    const res = await fetch(`${UPDATE_BASE_URL}/version.json?t=${Date.now()}`, {
      cache: 'no-store'
    });
    if (res.ok) {
      return await res.json();
    }
    return null;
  } catch (e) {
    console.warn('Failed to fetch latest version:', e);
    return null;
  }
};

export const compareVersions = (v1: string, v2: string): number => {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 < p2) return -1;
    if (p1 > p2) return 1;
  }
  return 0;
};

export const isUpdateAvailable = async (): Promise<{
  available: boolean;
  latestVersion: AppVersion | null;
  currentVersion: string;
  error: string | null;
}> => {
  try {
    if (!navigator.onLine) {
      return { available: false, latestVersion: null, currentVersion: getCurrentVersion(), error: 'OFFLINE' };
    }

    const latest = await fetchLatestVersion();
    if (!latest) {
      return { available: false, latestVersion: null, currentVersion: getCurrentVersion(), error: 'FETCH_FAILED' };
    }

    const current = getCurrentVersion();
    const comparison = compareVersions(current, latest.version);

    if (comparison < 0) {
      return { available: true, latestVersion: latest, currentVersion: current, error: null };
    }

    return { available: false, latestVersion: latest, currentVersion: current, error: null };
  } catch (e) {
    return {
      available: false,
      latestVersion: null,
      currentVersion: getCurrentVersion(),
      error: e instanceof Error ? e.message : 'UNKNOWN_ERROR'
    };
  }
};

export const downloadUpdate = (
  latestVersion: AppVersion,
  onProgress?: (progress: number) => void
): Promise<boolean> => {
  return new Promise(async (resolve) => {
    try {
      if (!navigator.onLine) {
        resolve(false);
        return;
      }

      onProgress?.(10);

      // Fetch the main app files from the update URL
      const filesToCache = [
        '/index.html',
        '/manifest.json',
        '/icon.png',
        '/sw.js',
        '/server-config.json'
      ];

      let downloaded = 0;
      const total = filesToCache.length;

      if ('caches' in window) {
        const cache = await caches.open('uniteam-update-cache');

        for (const file of filesToCache) {
          try {
            const res = await fetch(`${latestVersion.updateUrl}${file}?t=${Date.now()}`, {
              cache: 'no-store'
            });
            if (res.ok) {
              await cache.put(file, res);
            }
          } catch (e) {
            console.warn(`Failed to cache ${file}:`, e);
          }
          downloaded++;
          onProgress?.(10 + (downloaded / total) * 70);
        }

        onProgress?.(80);

        // Also cache the main assets
        try {
          const assetsRes = await fetch(`${latestVersion.updateUrl}/assets/manifest.json?t=${Date.now()}`, {
            cache: 'no-store'
          });
          if (assetsRes.ok) {
            const assetsManifest = await assetsRes.json();
            const assetFiles = Object.values(assetsManifest) as string[];

            let assetDownloaded = 0;
            for (const asset of assetFiles) {
              try {
                const assetRes = await fetch(`${latestVersion.updateUrl}/${asset}?t=${Date.now()}`, {
                  cache: 'no-store'
                });
                if (assetRes.ok) {
                  await cache.put(`/${asset}`, assetRes);
                }
              } catch (e) {
                console.warn(`Failed to cache asset ${asset}:`, e);
              }
              assetDownloaded++;
              onProgress?.(80 + (assetDownloaded / assetFiles.length) * 15);
            }
          }
        } catch (e) {
          console.warn('Failed to cache assets:', e);
        }
      }

      onProgress?.(95);

      // Save the new version info
      cacheCurrentVersion(latestVersion);

      // Update the service worker cache
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        try {
          await navigator.serviceWorker.ready;
          navigator.serviceWorker.controller.postMessage({ type: 'UPDATE_AVAILABLE' });
        } catch (e) {
          console.warn('Failed to notify service worker:', e);
        }
      }

      onProgress?.(100);
      resolve(true);
    } catch (e) {
      console.error('Download update failed:', e);
      resolve(false);
    }
  });
};

export const applyUpdate = (): void => {
  // Clear old cache and reload
  if ('caches' in window) {
    caches.keys().then(keys => {
      keys.forEach(key => {
        if (key !== 'uniteam-update-cache') {
          caches.delete(key);
        }
      });
    });
  }

  // Rename update cache to main cache
  if ('caches' in window) {
    caches.open('uniteam-update-cache').then(updateCache => {
      caches.open('uniteam-cache-v4').then(mainCache => {
        updateCache.keys().then(requests => {
          requests.forEach(request => {
            updateCache.match(request).then(response => {
              if (response) {
                mainCache.put(request, response);
              }
            });
          });
        });
      });
    });
  }

  // Reload the page to apply new version
  window.location.reload();
};

export const getInitialStatus = (): UpdateStatus => ({
  checking: false,
  available: false,
  downloading: false,
  progress: 0,
  ready: false,
  error: null,
  currentVersion: getCurrentVersion(),
  latestVersion: null,
  releaseNotes: null
});
